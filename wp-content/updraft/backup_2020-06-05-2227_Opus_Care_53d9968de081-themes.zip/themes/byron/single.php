<!-- Página de posts do site -->
<?php get_header(); ?>

<?php get_footer(); ?>