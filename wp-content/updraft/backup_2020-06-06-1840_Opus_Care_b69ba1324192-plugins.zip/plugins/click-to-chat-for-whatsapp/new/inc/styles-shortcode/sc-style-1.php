<?php
/**
 * 
 * 
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// $s1_options = get_option( 'ht_ctc_s1' );
// $s1_img_size = esc_attr( $s1_options['s1_img_size'] );


$o .=  '
    <button class="ctc-analytics">'.$call_to_action.'</button>
';

?>