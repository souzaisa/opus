<!-- 
    Arquivo para o código do footer da página,
    footer = rodapé da página
-->

<footer class="page-footer">
    <div class="footer-copyright">
        <div class="container center">
            <p> Desenvolvido por </p>
            <a href="http://byronsolutions.com" target="_blank" title="Site da byron.solutions">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/img/logo.png" alt="Logo da byron.solutions" title="Logo da byron.solutions">
            </a>
        </div>
    </div>
</footer>

<?php wp_footer() ?>
</body>
</html>